//
//  Places.swift
//  Appa
//
//  Created by Shikha Mehta on 3/8/16.
//  Copyright © 2016 ASU. All rights reserved.
//

import Foundation
import CoreData


class Places: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
